import 'package:flutter/material.dart';
import 'package:projeto_1/ui/home.ui.dart';

void main() {
  runApp(MaterialApp(
    title: "Primeiro App",
    home: Home(),
  ));
}

