import 'package:projeto_1/model/animal.model.dart';

class Gato extends Animal{

  bool querIgnorarOSerHumano(){
    return true;
  }


}